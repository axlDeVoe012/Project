package com.jozitechies.StreetSmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreetSmartApplicationTests {

	@Test
	void contextLoads() {
	}

}
