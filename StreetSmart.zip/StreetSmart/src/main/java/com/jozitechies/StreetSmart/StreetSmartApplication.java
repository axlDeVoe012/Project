package com.jozitechies.StreetSmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreetSmartApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreetSmartApplication.class, args);
	}

}
